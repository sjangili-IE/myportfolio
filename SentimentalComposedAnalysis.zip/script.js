document.addEventListener("DOMContentLoaded", function() {
    const backToTopButton = document.getElementById("backToTop");

    // Check if the user has scrolled to the bottom of the page
    function isAtBottom() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight;
        return scrollTop + windowHeight >= documentHeight - 50; // Adjust threshold if needed
    }

    // Show or hide the button based on scroll position
    window.addEventListener("scroll", function() {
        if (isAtBottom()) {
            backToTopButton.style.display = "block";
        } else {
            backToTopButton.style.display = "none";
        }
    });

    // Scroll to the top when the button is clicked
    backToTopButton.addEventListener("click", function() {
        window.scrollTo({
            top: 0,
            behavior: "smooth", // Smooth scrolling effect
        });
    });
});
#backToTop {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background - color: #4caf50;
    color: white;
    border: none;
    border - radius: 50px;
    padding: 10px 15px;
    font - size: 16px;
    cursor: pointer;
    box - shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    transition: opacity 0.3s ease;
    display: none; /* Hidden by default */
    z - index: 1000;
}

#backToTop:hover {
    background - color: #388e3c;
}

#backToTop:active {
    transform: scale(0.95);
}
